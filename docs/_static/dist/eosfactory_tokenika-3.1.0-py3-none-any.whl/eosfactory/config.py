import eosfactory.core.config

if __name__ == '__main__':
    eosfactory.core.config.main()
