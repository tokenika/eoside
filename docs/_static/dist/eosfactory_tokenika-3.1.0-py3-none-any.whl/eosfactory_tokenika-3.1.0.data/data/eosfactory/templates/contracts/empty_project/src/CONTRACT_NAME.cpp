#include <${CONTRACT_NAME}.hpp>
